# monitor/network_monitor.py
import psutil
import time
import threading
import queue

class NetworkMonitor(threading.Thread):
    def __init__(self, out_queue: queue.Queue, interval=2.0):
        super().__init__(daemon=True)
        self.out_queue = out_queue
        self.interval = interval
        self._stop = threading.Event()

    def run(self):
        while not self._stop.is_set():
            try:
                conns = psutil.net_connections(kind='inet')
                for c in conns:
                    event = {
                        'type': 'net_conn',
                        'fd': getattr(c,'fd',None),
                        'laddr': getattr(c,'laddr',None)._asdict() if getattr(c,'laddr',None) else None,
                        'raddr': getattr(c,'raddr',None)._asdict() if getattr(c,'raddr',None) else None,
                        'status': c.status,
                        'pid': c.pid,
                        'timestamp': time.time()
                    }
                    self.out_queue.put(event)
            except Exception:
                pass
            time.sleep(self.interval)

    def stop(self):
        self._stop.set()
