# app.py
from flask import Flask, Response, request, jsonify, stream_with_context, send_from_directory
import queue, threading, json, time, os
from monitor.process_monitor import ProcessMonitor
from monitor.network_monitor import NetworkMonitor
from monitor.file_monitor import FileMonitor
from mitigation.actions import MitigationEngine
from detection.anomaly_model import SimpleAnomalyModel
from detection.signature import YaraScanner
import numpy as np

app = Flask(__name__, static_folder='static')

# central event queue
event_q = queue.Queue()

# Start monitors
proc_monitor = ProcessMonitor(event_q, interval=1.0)
net_monitor = NetworkMonitor(event_q, interval=2.0)
file_mon = FileMonitor(event_q)
proc_monitor.start()
net_monitor.start()
file_mon.start()

# detectors & mitigator
mitigator = MitigationEngine()
detector = SimpleAnomalyModel()
scanner = YaraScanner()  # will load yara rules if present

# optional: train detector on short baseline (very small fallback)
try:
    bs = []
    for _ in range(10):
        ev = event_q.get(timeout=1)
        if ev.get('type')=='process_sample':
            bs.append([ev.get('cpu_percent') or 0.0, ev.get('mem_percent') or 0.0])
    if len(bs) >= 5:
        X = np.array(bs)
        detector.train(X)
except Exception:
    pass


@app.route('/')
def index():
    return send_from_directory('static', 'index.html')


@app.route('/api/stream')
def stream():
    def gen():
        while True:
            try:
                event = event_q.get(timeout=5)
            except queue.Empty:
                yield ':\n\n'  # keepalive comment for SSE
                continue

            out = { 'event': event }

            # if process sample, run detectors
            if event.get('type')=='process_sample':
                features = np.array([event['cpu_percent'] or 0.0, event['mem_percent'] or 0.0])
                label = detector.predict(features)
                score = detector.score(features)
                out['detection'] = { 'label': int(label), 'score': float(score) }

            # run yara on executable path if exists
            exe = event.get('exe')
            if exe:
                yara_res = scanner.scan_file(exe)
                if yara_res:
                    out['yara'] = yara_res

            # File events → YARA scan
            if event.get('type')=='file_event':
                y = scanner.scan_file(event.get('path'))
                if y:
                    out['yara'] = y
                    out['mitre'] = out.get('mitre') or []
                suspicious = bool(out.get('yara'))
                if suspicious:
                    incident = {
                        'ts': time.time(),
                        'event': event,
                        'detection': out.get('detection'),
                        'yara': out.get('yara'),
                        'mitre': out.get('mitre')
                    }
                    INCIDENTS.append(incident)
                    if len(INCIDENTS) > MAX_INCIDENTS:
                        del INCIDENTS[:len(INCIDENTS)-MAX_INCIDENTS]

            yield f"data: {json.dumps(out, default=str)}\n\n"

    return Response(stream_with_context(gen()), mimetype='text/event-stream')


@app.route('/api/mitigate', methods=['POST'])
def api_mitigate():
    data = request.json or {}
    action = data.get('action')
    if action == 'kill_process':
        pid = data.get('pid')
        res = mitigator.kill_process(pid)
        return jsonify(res)
    if action == 'quarantine_file':
        path = data.get('path')
        res = mitigator.quarantine_file(path)
        return jsonify(res)
    return jsonify({'status':'error','error':'unknown action'}), 400


if __name__ == '__main__':
    # ensure static exists
    os.makedirs('static', exist_ok=True)
    print('Starting app on http://127.0.0.1:5000')
    app.run(debug=True, port=5000)


@app.route('/api/yara/reload', methods=['POST'])
def api_yara_reload():
    ok = scanner.reload()
    return jsonify({'status': 'ok' if ok else 'no_rules'})
