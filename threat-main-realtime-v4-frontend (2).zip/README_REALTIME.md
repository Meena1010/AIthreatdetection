# threat-main — RealTime version

## Run (local)

1. Create virtualenv and install requirements:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. Start backend (serves static files too):

```bash
python app.py
```

3. Open UI: http://127.0.0.1:5000/

## Notes
- Mitigation actions may need elevated privileges (killing system processes).
- Test in an isolated environment (VM) first.
