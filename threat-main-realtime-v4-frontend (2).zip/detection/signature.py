# detection/signature.py
try:
    import yara
except Exception:
    yara = None
import os

class YaraScanner:
    def __init__(self, rules_dir='yara_rules'):
        self.rules_dir = rules_dir
        self.rules = None
        self.reload()

    def reload(self):
        if yara is None:
            self.rules = None
            return False
        files = []
        if os.path.isdir(self.rules_dir):
            for f in os.listdir(self.rules_dir):
                if f.endswith('.yar') or f.endswith('.yara'):
                    files.append(os.path.join(self.rules_dir, f))
        if not files:
            self.rules = None
            return False
        try:
            self.rules = yara.compile(filepaths={str(i): fp for i, fp in enumerate(files)})
            return True
        except Exception:
            self.rules = None
            return False

    def scan_file(self, path):
        if yara is None or self.rules is None or not path or not os.path.exists(path):
            return None
        try:
            matches = self.rules.match(path)
            if not matches:
                return None
            # Return rule names
            out = []
            for m in matches:
                out.append(m.rule if hasattr(m, 'rule') else str(m))
            return out if out else None
        except Exception:
            return None
