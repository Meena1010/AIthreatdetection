# run_integrated_system.py
import subprocess
import sys
import os

if __name__ == '__main__':
    print('Starting Flask backend...')
    os.execv(sys.executable, [sys.executable, 'app.py'])
